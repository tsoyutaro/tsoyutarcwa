# 厚いPMMAシート下面の1次元逆台形格子

ユーザー指定の構造を、既存20260806系RCWAの `studies/pmma_sheet_relief_1d/` に追加する計算です。既存のRCWA本体・過去のstudyは変更しません。添付図は寸法と材料式の参考として扱い、最終の指定を優先します。図の周期5.0 µm、屈折率1.515は使用しません。

## 確定したモデル

- 光は上側の空気から垂直入射。x方向のみ周期的、y方向に一様。s偏光はEがy方向、p偏光はHがy方向です。
- シートと構造は同じPMMA、k=0。厚いシートの干渉縞は位相平均で除きます。上面の空気/PMMAフレネル反射と、戻った回折光の再反射も含めます。
- シート下面から下向きに突出する逆台形。長辺3.72 µm、短辺1.50 µm、高さ1.50 µmです。短辺が有限なので、厳密な三角形ではありません。
- **長辺を固定**し、周期3.72 µm（根元の隙間0）と周期3.92 µm（根元の隙間0.20 µm）を比較します。0.20 µmは有限幅の谷底を設ける最初の設計案であり、光学最適値や製造保証値ではありません。必要なら周期3.82/4.02/4.22 µmなども比較できます。
- 空気条件：構造の隙間は空気。裸のPMMA先端、またはAu先端表面に接する平坦な水面から下側が半無限水。
- 水条件：構造の隙間もすべて水で満たし、その先も半無限水。水は n=1.333、k=0の定数です。
- 波長は真空波長400～700 nm。既定のスペクトル刻みは5 nmです。入射角は0°固定。「20°以内」は反射光の集光半角を意味します。
- Auは試料側からシートに向かう平行な蒸着流を想定します。光の入射方向とは逆です。水平面の膜厚50 nm、斜面の法線膜厚29.742 nm、斜面のx方向の厚さ37.000 nmが同時に成立します。

![全4条件・周期3.72 µm](results/geometry/conditions_P3720.png)

![全4条件・周期3.92 µm](results/geometry/conditions_P3920.png)

水面は理想的な平面として固定し、濡れ・毛管圧・メニスカスは解きません。Auの粗さ、島状化、密度差、密着層は含めません。周期3.72 µmの根元の谷底は数学的には幅0であり、水平な谷底Au膜を有限面積で設けたい場合に0.20 µm隙間案が役立ちます。NILでは離型・充填・角の丸みも効くので、この隙間値は金型・樹脂・離型処理と合わせて評価する初期値です。

## 実行

既存RCWAプロジェクトのルート（`rcwa_ext/` と `studies/` がある場所）から実行します。Pythonと既存環境のnumpy/scipy/matplotlib/torch/torcwaが必要です。別の場所から実行する場合は `--solver-root` または環境変数 `RCWA_ROOT` でそのルートを指定します。

```powershell
# 構造図のみ
python studies/pmma_sheet_relief_1d/run.py --preview-only --output-dir studies/pmma_sheet_relief_1d/results/geometry_preview

# 物理検証（フレネル、Au薄膜Airy式、エネルギー保存、カットオフ等）
python studies/pmma_sheet_relief_1d/validate.py

# まずAuなし。両周期・空気/水・s/pを一括計算
python studies/pmma_sheet_relief_1d/uncoated/run_spectrum.py --wavelengths 400:700:5 --order 24 --slices 120 --phase-max 131072

# 後段のAu 50nm計算。初めは少数波長で検証
python studies/pmma_sheet_relief_1d/gold/run_spectrum.py --wavelengths 400,550,700 --order 32 --slices 240

# Auなしのフーリエ次数収束。層数は固定
python studies/pmma_sheet_relief_1d/converge.py --axis order --values 16,24,32,40,48 --wavelengths 400,550,700 --slices 240 --phase-tol 0.0001 --phase-max 131072

# Auなしの層数収束。フーリエ次数は固定
python studies/pmma_sheet_relief_1d/converge.py --axis slices --values 60,120,240,480 --wavelengths 400,550,700 --order 48 --phase-tol 0.0001 --phase-max 131072

# Auの場合は収束コマンドに --coating gold を追加
# 運動学的に許される全次数・角度を出力（効率はRCWAで計算）
python studies/pmma_sheet_relief_1d/kinematics.py
```

`--device cuda` で既存GPU環境を使えます。現在確認したローカル環境はCPUです。`--periods 3920 --voids air` のように条件を限定できます。

Mは最大フーリエ次数で、保持する調和成分は `-M,...,M` の2M+1本、y次数は0だけです。物理的な伝搬次数と数値計算の打ち切り次数は別物です。エバネッセント成分も必要なので、伝搬次数をすべて含めただけでは収束とは言えません。

Nz（`--slices`）はPMMA高さを基準にした最大層厚 `H/Nz` の指定です。Auなしでは有限層数=Nz。Auありでは谷底50 nmと先端1500 nm、先端Au終端1550 nmの境界を正確に置くため、有限層数が増えます。Nz120のAuモデルは124層、Nz240は248層です。端の空気・PMMAポート・半無限水はこの層数に含めません。

## 出力

| ファイル | 内容 |
|---|---|
| `spectra.csv` | 各条件・波長・偏光のR/T、全吸収A、0次反射、回折反射合計、20°以内/外の反射、位相平均誤差 |
| `diffraction_orders.csv` | 各次数mのR_m/T_m、反射側空気・透過側水・PMMA内部の符号付き角度、伝搬可否 |
| `local_single_pass_orders.csv` | 上面からの戻りを含める前の、PMMAから局所構造への1回入射の回折効率 |
| `settings.json` | 全設定、材料CSVハッシュ、ソースハッシュ、数値手法 |
| `cache/*.json` | 設定・ソース・材料が一致する点の再利用用キャッシュ |
| `geometry/` | 全条件のPNG/SVG、実際に使う層断面CSV |
| `completion.json` | 位相平均の合否と、次数・層数収束が未確認であることの記録 |
| `adjacent_changes.csv` | 収束実行時、R/T/A・全次数・集光角内外の最大変化 |
| `convergence.json` | 最後の連続2回の変化が許容値以内かを判定 |

R_m/T_mは最初に空気側へ入射した全パワーを1として規格化します。内部PMMAの反射次数には、空気上面で全反射して再び構造へ戻るものがあります。そのため局所反射と外部で観測する反射は一致しません。角度は反射光では上向き法線、透過光では下向き法線から測り、符号はx方向です。20°以内の合計には0次を含みます。外部の出力側は**空気条件でも水**です。

「吸収のm次」は出射回折光のようには一意に定義できません。したがって `A_total=1-sum(R_m)-sum(T_m)` を出します。各mについて `1-R_m-T_m` と定義してはいけません。AuなしはPMMA・空気・水が無損失なのでA=0です。出力にある±1e-12程度の値は丸め誤差です。AuありはこのモデルではAuだけが吸収します。

収束許容値の既定値は絶対パワー比1e-3（0.1パーセントポイント）です。位相平均の誤差指標も併せて確認し、収束比較では次数・層数の許容値の1/4以下を要求します。3点の波長だけで確認した合格はその3点に限るため、最終的には400～700 nmの使用する全波長で両方の収束を調べてください。Au薄膜や共鳴では、さらに細かな次数・層数・波長の検討が必要です。

## 材料

PMMAは既存 `studies/pmma_gold_grating_1d/data/Szczurowski.csv` をコピーしました。元データは0.4047～1.083 µm、nのみで、k=0と仮定します。nを波長で線形補間します。400～404.7 nmのみ、添付式から求めた400 nmのn=1.5058699743と、CSV最初の404.7 nmのn=1.5051867964を直線で結びます。これによりCSVを外挿せず、接続時の段差も避けます。400 nm以外のCSV範囲外へは外挿しません。CSVを取り除いた場合だけ、指定400～700 nm全域で添付式に切り替わります。

添付式（λの単位はµm）をそのまま記録します。分母の定数をさらに2乗しません。

\[
n^2-1=\frac{0.99654\lambda^2}{\lambda^2-0.00787}
+\frac{0.18964\lambda^2}{\lambda^2-0.02191}
+\frac{0.00411\lambda^2}{\lambda^2-3.85727}.
\]

Auは既存 `studies/mosmite_gold_deposition/data/Au_Johnson_1972.csv` をコピーしました。187.9～1937 nmのJohnson–Christyデータです。nとkをそれぞれ線形補間し、その後 `epsilon=(n+i*k)^2` とします。時間依存は `exp(-i*omega*t)`、正のkが吸収です。

## 高速化と適用範囲

既存 `studies/gold_grating_1d/solver.py` のs/p分離、2M+1次元固有値問題、逐次Redheffer接続を再利用します。断面の区間フーリエ係数を解析的に計算するためxyの画素格子は不要です。場分布保存を切り、必要な局所Tf/Rfだけを計算します。シートの位相平均だけは左右対称性を使い、±mの偶対称成分に縮約します。位相平均は行列のバッチsolveで行い、同じ局所RCWAを位相のたびに解き直しません。全体はcomplex128です。

シートは「厚いから全干渉を消す」のではなく、**シート往復位相だけ**を平均します。構造内部・Au薄膜・空気溝の干渉や回折はRCWAに残します。位相平均は各|m|に独立な一様位相を与え、縮退している+mと-mには同じ位相を与えます。これは十分な厚さばらつき・有限コヒーレンスで角度ごとの位相が失われるモデルであり、膜厚が大きいだけの完全単色・完全平行光に対する特定膜厚の厳密解ではありません。有限膜厚と光源帯域を指定する計算は別モデルです。

## 参考資料

- [回折方程式：Plymouth Grating Laboratory](https://www.plymouthgrating.com/guidance/technical-notes/fundamentals/the-grating-equation/)
- [PMMA Szczurowskiデータ](https://refractiveindex.info/?shelf=organic&book=poly_methyl_methacrylate&page=Szczurowski)
- [Johnson–Christy原論文](https://doi.org/10.1103/PhysRevB.6.4370)
- [テーパ側壁と離型力の一次研究](https://www.sciencedirect.com/science/article/abs/pii/S0167931708005558)
- [NIL金属/ポリマー格子の離型に関する一次研究](https://www.nature.com/articles/s41598-018-31194-y)

0.20 µmという隙間自体は本計算の設計判断であり、これらの論文がこの寸法を推奨したという意味ではありません。
