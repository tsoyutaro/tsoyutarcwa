# 保存済みデータから報告書を再生成する

RCWA自体は再実行しません。同梱source_dataの保存結果を読み、図・HTML・PDFを作り直します。
WindowsのMS Gothicフォント（C:/Windows/Fonts/msgothic.ttc）を使用します。
Pythonパッケージはnumpy、pandas、matplotlib、Pillow、reportlabが必要です。

1. python reproduce_report/complete_results.py
2. python reproduce_report/assemble_results.py
3. python reproduce_report/make_results_pdf.py

既存の図・報告書を上書きするので、必要に応じて配布フォルダをコピーしてから実行してください。
この3ファイルは本報告書を生成したスクリプトを、配布フォルダのsource_dataを参照するよう調整したものです。
