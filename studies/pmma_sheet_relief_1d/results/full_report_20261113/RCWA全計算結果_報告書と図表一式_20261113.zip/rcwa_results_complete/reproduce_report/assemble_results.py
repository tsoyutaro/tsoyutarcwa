from __future__ import annotations

import base64
import csv
import hashlib
import html
import json
from pathlib import Path
import shutil

import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'source_data'
OUT=ROOT
content=json.loads((OUT/'report_content.json').read_text(encoding='utf-8'))
paths=[('uncoated','Auなし / 全61波長','uncoated'),('gold','Auあり / 550 nm','gold_smoke_550nm')]
paths += [(f'order_{m}',f'次数 M={m} / Nz=120',f'convergence_order/order_{m}') for m in [16,24,32,40,48]]
paths += [(f'slices_{n}',f'層数 Nz={n} / M=40',f'convergence_slices/slices_{n}') for n in [60,120,240,480]]
PACK={};APPENDIX=[]
keys=['period_nm','void','polarization','wavelength_nm','m']
for key,label,path in paths:
    folder=SRC/'results'/path
    s=pd.read_csv(folder/'spectra.csv')
    o=pd.read_csv(folder/'diffraction_orders.csv')
    l=pd.read_csv(folder/'local_single_pass_orders.csv')
    o=o.merge(l,on=['coating',*keys],how='left',validate='one_to_one')
    zero=o[o.m==0].set_index(keys[:-1]).T_m
    s=s.join(zero.rename('T_0'),on=keys[:-1]);s['T_diffraction']=s['T']-s.T_0
    summary=json.loads(s.to_json(orient='records',double_precision=14,force_ascii=False))
    groups={}
    cols=['wavelength_nm','m','R_m','T_m','theta_R_air_deg','theta_T_output_deg','theta_PMMA_deg',
          'R_PMMA_single_pass','T_water_single_pass','A_local_total']
    for (period,void,pol),g in o.groupby(keys[:3]):
        groups[f'{period:g}|{void}|{pol}']=json.loads(g[cols].to_json(orient='values',double_precision=14))
    PACK[key]=dict(label=label,summary=summary,groups=groups)
    for (period,void,pol),g in s.groupby(keys[:3]):
        table=[]
        for _,r in g.sort_values('wavelength_nm').iterrows():
            table.append([f'{r.wavelength_nm:g}',f'{100*r.R:.5f}',f'{100*r["T"]:.5f}',f'{100*r.A_total:.2e}',
                f'{100*r.R_0:.5f}',f'{100*r.R_diffraction:.5f}',f'{100*r.T_0:.5f}',f'{100*r.T_diffraction:.5f}',
                f'{100*r.R_le_20deg:.5f}',f'{100*r.R_gt_20deg:.5f}',str(int(r.phase_points_per_scramble)),f'{100*r.phase_error:.5f}'])
        APPENDIX.append(dict(run=key,title=f'{label} / 周期{period/1000:.2f} µm / {"空気溝" if void=="air" else "水充填"} / {pol}',
            headers=['λ nm','R %','T %','A %','R0 %','Rdiff %','T0 %','Tdiff %','R≤20° %','R>20° %','Nφ/回','εφ pp'],rows=table))
(OUT/'appendix_tables.json').write_text(json.dumps(APPENDIX,ensure_ascii=False,indent=2),encoding='utf-8')

# Preserve every previously delivered result, with source hashes.
if SRC.resolve() != (OUT/'source_data').resolve():
    shutil.copytree(SRC,OUT/'source_data',dirs_exist_ok=True,
        ignore=shutil.ignore_patterns('*.py','*.pyc','__pycache__','requirements.txt','installation.json'))
inventory=[]
for p in sorted((OUT/'source_data').rglob('*')):
    if p.is_file():
        row=dict(path=p.relative_to(OUT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rows='')
        if p.suffix=='.csv':
            with p.open(encoding='utf-8-sig',newline='') as f:row['rows']=max(0,sum(1 for _ in csv.reader(f))-1)
        inventory.append(row)
pd.DataFrame(inventory).to_csv(OUT/'tables/source_inventory.csv',index=False,encoding='utf-8-sig')


def htmltable(t,cls=''):
    return '<div class="tablewrap '+cls+'"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in t['headers'])+\
        '</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in r)+'</tr>' for r in t['rows'])+'</tbody></table></div>'


def mdtable(t):
    return '| '+' | '.join(t['headers'])+' |\n| '+' | '.join(['---']*len(t['headers']))+' |\n'+\
        '\n'.join('| '+' | '.join(str(v).replace('|','/') for v in r)+' |' for r in t['rows'])


sections=[];md=['# RCWA計算結果の全記録','',
    '2026年11月13日 / 保存済み結果の再集計・可視化。新しいRCWA実行は追加していません。','',
    '全ての次数別数値は同梱HTMLの選択ビューア、またはsource_data内のCSVで確認できます。全合計値712行は本書の付録にも掲載します。','']
for i,s in enumerate(content['sections']):
    body='<section id="sec'+str(i)+'"><h2>'+html.escape(s['title'])+'</h2>'
    md += ['## '+s['title'],'']
    for p in s['paragraphs']:
        body+='<p>'+html.escape(p)+'</p>';md += [p,'']
    if s['figure']:
        pic=OUT/s['figure'];encoded=base64.b64encode(pic.read_bytes()).decode()
        body+='<img class="science" alt="'+html.escape(s['title'])+'" src="data:image/png;base64,'+encoded+'">'
        md += ['!['+s['title']+']('+s['figure']+')','']
    for t in s['tables']:
        body+=htmltable(t);md += [mdtable(t),'']
    sections.append(body+'</section>')
md += ['## 付録：全合計値の表','',
       'RdiffとTdiffはm≠0の合計。Nφは1 scramble当たりの点数で、scrambleは2回。εφは位相平均の変化指標です。Aの微小な負値は丸め誤差です。','']
for t in APPENDIX:
    md += ['### '+t['title'],'',mdtable(t),'']
(OUT/'全結果_詳細説明.md').write_text('\n'.join(md),encoding='utf-8')

css='''*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font:16px/1.8 "Yu Gothic",Meiryo,sans-serif;color:#213943;background:#f0f4f5}header{background:#143f50;color:#fff;padding:42px max(24px,calc((100vw - 1180px)/2))}header h1{font-size:30px;margin:0 0 10px}header p{margin:8px 0;color:#e1edf0}main{max-width:1240px;margin:auto;padding:24px}section,.viewer{background:white;padding:28px 32px;margin-bottom:24px;border-radius:12px;border:1px solid #dce5e7}h2{font-size:22px;border-left:5px solid #258090;padding-left:14px;line-height:1.5}h3{font-size:18px;margin-top:28px}.science{display:block;width:100%;height:auto;margin:22px 0}.muted{color:#5c717b;font-size:14px}.warning{padding:12px 18px;background:#fff4df;border-left:4px solid #b77b20}.controls{display:flex;flex-wrap:wrap;gap:14px;align-items:end}label{font-size:14px;display:block}select,button{font:inherit;border:1px solid #b6c8ce;border-radius:6px;background:white;padding:7px 10px;max-width:100%}button{background:#175d72;color:#fff;cursor:pointer}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:22px 0}.card{background:#eef5f6;border-radius:8px;padding:14px}.card strong{display:block;font-size:30px;line-height:1.4}.balance{display:flex;height:28px;border-radius:5px;overflow:hidden;background:#ddd}.balance span{display:block;text-align:center;color:#fff;font-size:12px}.charts{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:16px 0}svg{width:100%;height:auto}.tablewrap{overflow:auto;border:1px solid #dce5e7;border-radius:6px;margin-top:18px}table{border-collapse:collapse;font-size:12px;width:100%;white-space:nowrap}th,td{padding:6px 9px;text-align:right;border-bottom:1px solid #e4ecef}th{background:#e6f0f3;color:#244651;position:sticky;top:0}tr:nth-child(even){background:#f7fafb}td:first-child,th:first-child{text-align:left}.order-table{max-height:500px}nav{background:white;padding:20px 28px;margin-bottom:24px;border-radius:10px}nav a{display:inline-block;margin:3px 14px 3px 0;font-size:14px;color:#176782}details{background:white;padding:14px 20px;border:1px solid #dce5e7;margin:8px 0;border-radius:7px}summary{cursor:pointer}.appendix details .tablewrap{max-height:600px}a{color:#176782}@media(max-width:760px){main{padding:10px}section,.viewer{padding:16px}.charts{grid-template-columns:1fr}.cards{gap:6px}.card{padding:9px}.card strong{font-size:18px;white-space:nowrap}header{padding:24px}header h1{font-size:22px}}@media print{.controls,nav,button{display:none}section{break-inside:avoid;border:0}body{background:white}.viewer{break-after:page}}'''
viewer='''<section class="viewer" id="viewer"><h2>全計算・全次数の選択ビューア</h2><p>保存された全11系列を切り替えられます。既存の712件の合計値、39,880行の外部次数別結果と同数の局所次数別結果を収録しています。</p><div class="controls"><label>計算系列<select id="run"></select></label><label>周期 (µm)<select id="period"><option value="3720">3.72</option><option value="3920">3.92</option></select></label><label>溝内<select id="void"><option value="air">空気</option><option value="water">水</option></select></label><label>偏光<select id="pol"><option>s</option><option>p</option></select></label><label>波長 (nm)<select id="wave"></select></label></div><div class="cards"><div class="card">反射 R<strong id="rval"></strong></div><div class="card">透過 T<strong id="tval"></strong></div><div class="card">全吸収 A<strong id="aval"></strong></div></div><div id="balance" class="balance"></div><p id="details" class="muted"></p><div class="charts"><div id="angularR"></div><div id="angularT"></div></div><div class="controls"><label>次数別スペクトルの m<select id="mselect"></select></label><button id="download">表示条件の全次数CSVを保存</button><label><input type="checkbox" id="evan">遠方に伝搬しない保持次数も表に表示</label></div><div id="curve"></div><div id="orderTable" class="tablewrap order-table"></div><p class="muted">角度は法線から測る符号付き角度。R/Tの規格化基準は最初の外部入射パワーです。局所R/TはPMMAへ1回入射するパワーが基準です。吸収は全体量で、出射次数別Aを定義していません。</p></section>'''
js=r'''
const D=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id);
const fmt=(x,n=5)=>x===null||x===undefined?'—':Number(x).toFixed(n);
Object.entries(D).forEach(([k,v])=>$('run').add(new Option(v.label,k)));
function casekey(){return `${$('period').value}|${$('void').value}|${$('pol').value}`}
function dataset(){return D[$('run').value]}
function rows(){return dataset().groups[casekey()]||[]}
function summary(){return dataset().summary.find(r=>r.period_nm==$('period').value&&r.void==$('void').value&&r.polarization==$('pol').value&&r.wavelength_nm==$('wave').value)}
function init(){let old=Number($('wave').value)||550,ws=[...new Set(rows().map(r=>r[0]))].sort((a,b)=>a-b);$('wave').replaceChildren(...ws.map(w=>new Option(w,w)));$('wave').value=ws.reduce((a,b)=>Math.abs(b-old)<Math.abs(a-old)?b:a);let ms=[...new Set(rows().map(r=>r[1]))].sort((a,b)=>a-b),mo=Number($('mselect').value)||0;$('mselect').replaceChildren(...ms.map(m=>new Option(m,m)));$('mselect').value=ms.includes(mo)?mo:0;update()}
function svgplot(series,title,xlabel,ylabel,xmin,xmax,ymax,stem=false){const W=640,H=280,L=62,T=36,R=18,B=45,cw=W-L-R,ch=H-T-B;let el=[];const X=x=>L+(x-xmin)/(xmax-xmin)*cw,Y=y=>T+ch-y/Math.max(ymax,1e-9)*ch;el.push(`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${title}"><rect width="100%" height="100%" fill="white"/><text x="${L}" y="20" font-size="15" fill="#274651">${title}</text>`);for(let i=0;i<=4;i++){let yy=ymax*i/4,xx=xmin+(xmax-xmin)*i/4;el.push(`<path d="M${L},${Y(yy)}H${W-R}" stroke="#e0e8eb"/><text x="${L-8}" y="${Y(yy)+4}" font-size="10" text-anchor="end">${yy.toFixed(ymax<1?3:1)}</text><text x="${X(xx)}" y="${H-25}" font-size="10" text-anchor="middle">${xx.toFixed(0)}</text>`)};el.push(`<path d="M${L},${T}V${H-B}H${W-R}" fill="none" stroke="#47606b"/>`);for(const s of series){let good=s.points.filter(p=>p[0]!==null&&p[1]!==null);if(stem){for(const p of good)el.push(`<line x1="${X(p[0])}" x2="${X(p[0])}" y1="${Y(0)}" y2="${Y(p[1])}" stroke="${s.color}"/>`)}else el.push(`<polyline fill="none" stroke="${s.color}" stroke-width="1.7" points="${good.map(p=>`${X(p[0])},${Y(p[1])}`).join(' ')}"/>`);for(const p of good)el.push(`<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="3" fill="${s.color}"><title>${s.label} ${p[2]??''}: x=${p[0].toFixed(5)}, ${p[1].toFixed(6)}%</title></circle>`)};el.push(`<text x="${W/2}" y="${H-4}" font-size="11" text-anchor="middle">${xlabel}</text><text transform="translate(15 ${H/2}) rotate(-90)" font-size="11" text-anchor="middle">${ylabel}</text>`);series.forEach((s,i)=>el.push(`<text x="${W-130}" y="${20+16*i}" fill="${s.color}" font-size="11">${s.label}</text>`));return el.join('')+'</svg>'}
function update(){let r=summary();if(!r)return;const rr=rows().filter(q=>q[0]==$('wave').value);$('rval').textContent=fmt(100*r.R)+' %';$('tval').textContent=fmt(100*r.T)+' %';$('aval').textContent=Math.abs(r.A_total)<1e-9?'≈ 0 %':fmt(100*r.A_total)+' %';$('balance').innerHTML=[['R',r.R,'#176782'],['T',r.T,'#168773'],['A',Math.max(0,r.A_total),'#b87917']].map(([k,v,c])=>`<span style="width:${100*v}%;background:${c}">${v>.05?k:''}</span>`).join('');$('details').textContent=`M=${r.order} / Nz=${r.slices} / 有限層${r.actual_layers} / R0=${fmt(100*r.R_0)}% / 回折反射=${fmt(100*r.R_diffraction)}% / R≤20°=${fmt(100*r.R_le_20deg)}% / R>20°=${fmt(100*r.R_gt_20deg)}% / 位相 ${r.phase_points_per_scramble}点×2 / 変化指標 ${fmt(100*r.phase_error,6)} pp`;
for(const [id,key,ang,color,title] of [['angularR',2,4,'#176782','空気側の各次数反射'],['angularT',3,5,'#168773','水側の各次数透過']]){let pts=rr.filter(q=>q[ang]!==null).map(q=>[q[ang],100*q[key],`m=${q[1]}`]);let ymax=Math.max(1e-3,...pts.map(p=>p[1]))*1.12;$(id).innerHTML=svgplot([{points:pts,label:title,color}],title,'法線からの角度 (°)','入射パワー (%)',-90,90,ymax,true)}
let shown=rr.filter(q=>$('evan').checked||q[4]!==null||q[5]!==null||q[6]!==null);$('orderTable').innerHTML='<table><thead><tr>'+['m','R_m %','T_m %','θR 空気 °','θT 水 °','θ PMMA °','局所R_m %','局所T_m %'].map(x=>`<th>${x}</th>`).join('')+'</tr></thead><tbody>'+shown.map(q=>'<tr>'+[q[1],fmt(100*q[2],7),fmt(100*q[3],7),fmt(q[4],4),fmt(q[5],4),fmt(q[6],4),fmt(100*q[7],7),fmt(100*q[8],7)].map(x=>`<td>${x}</td>`).join('')+'</tr>').join('')+'</tbody></table>';curve()}
function curve(){let m=Number($('mselect').value),a=rows().filter(q=>q[1]===m).sort((a,b)=>a[0]-b[0]),xmin=a[0]?.[0]??400,xmax=a.at(-1)?.[0]??700;if(xmin===xmax){xmin-=10;xmax+=10};let ymax=Math.max(1e-4,...a.flatMap(q=>[100*q[2],100*q[3]]))*1.15;$('curve').innerHTML=svgplot([{label:'R_m',color:'#176782',points:a.map(q=>[q[0],100*q[2]])},{label:'T_m',color:'#168773',points:a.map(q=>[q[0],100*q[3]])}],`m=${m} の全計算波長`,'真空波長 (nm)','入射パワー (%)',xmin,xmax,ymax)}
['run','period','void','pol'].forEach(id=>$(id).addEventListener('change',init));['wave','evan'].forEach(id=>$(id).addEventListener('change',update));$('mselect').addEventListener('change',curve);
$('download').onclick=()=>{let rr=rows().filter(q=>q[0]==$('wave').value),txt='wavelength_nm,m,R_m,T_m,theta_R_air_deg,theta_T_water_deg,theta_PMMA_deg,R_PMMA_single_pass,T_water_single_pass,A_local_total\n'+rr.map(q=>q.map(x=>x??'').join(',')).join('\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+txt],{type:'text/csv;charset=utf-8'}));a.download=`${$('run').value}_${casekey().replaceAll('|','_')}_${$('wave').value}nm_orders.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};init();
'''
nav='<nav><strong>内容</strong><br>'+''.join(f'<a href="#sec{i}">{html.escape(s["title"])}</a>' for i,s in enumerate(content['sections']))+'<a href="#appendix">全合計値の付録</a></nav>'
append='<section class="appendix" id="appendix"><h2>付録：計算済み全712件の合計値</h2><p>各条件を開くと全波長の数値を表示します。Aの極小値は丸め誤差です。εφは位相平均の変化指標で、厳密な誤差上界ではありません。</p>'+''.join('<details><summary>'+html.escape(t['title'])+'</summary>'+htmltable(t)+'</details>' for t in APPENDIX)+'</section>'
page='<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PMMA RCWA 全計算結果</title><style>'+css+'</style><header><h1>PMMAシート下面構造：全計算結果</h1><p>400-700 nm / s・p偏光 / 2周期 / 空気溝・水充填 / 2026年11月13日</p><p>Auなし全488条件、Auあり550 nm全8条件、次数・層数収束、全回折次数を収録。外部通信なしで動作します。</p></header><main><p class="warning">全帯域AuなしはM24・Nz120の初期試算です。Auありは550 nmのみ・離散化未収束です。代表波長の隣接差判定と全帯域最終精度を区別して記載しています。</p>'+viewer+nav+''.join(sections)+append+'</main><script id="data" type="application/json">'+json.dumps(PACK,ensure_ascii=False,separators=(',',':'),allow_nan=False).replace('</','<\/')+'</script><script>'+js+'</script></html>'
(OUT/'全結果_インタラクティブ.html').write_text(page,encoding='utf-8')
(OUT/'interactive_payload.json').write_text(json.dumps(PACK,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')
print(json.dumps({'summary_rows':sum(len(v['summary']) for v in PACK.values()),'order_rows':sum(sum(len(v) for v in p['groups'].values()) for p in PACK.values()),
                  'sections':len(content['sections']),'figures':len(content['images']),'html_bytes':len(page.encode()),'appendix_groups':len(APPENDIX)},ensure_ascii=False))
