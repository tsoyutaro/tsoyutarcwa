from __future__ import annotations

import csv
from html import escape
import json
from pathlib import Path

from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer,
                               Table, TableStyle, Image, PageBreak, NextPageTemplate, KeepTogether)

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT
C=json.loads((OUT/'report_content.json').read_text(encoding='utf-8'))
APP=json.loads((OUT/'appendix_tables.json').read_text(encoding='utf-8'))
PDF=OUT/'RCWA全計算結果_詳細報告書.pdf'
pdfmetrics.registerFont(TTFont('JP',r'C:\Windows\Fonts\msgothic.ttc',subfontIndex=0))
pdfmetrics.registerFont(TTFont('JPGothic',r'C:\Windows\Fonts\msgothic.ttc',subfontIndex=0))
INK=colors.HexColor('#243f4a');TEAL=colors.HexColor('#176782');LIGHT=colors.HexColor('#eaf2f4')
style=ParagraphStyle('body',fontName='JP',fontSize=9.2,leading=15,wordWrap='CJK',spaceAfter=9,textColor=INK)
small=ParagraphStyle('small',parent=style,fontSize=7.6,leading=11,spaceAfter=5)
title=ParagraphStyle('title',parent=style,fontSize=19,leading=27,spaceAfter=17,textColor=TEAL)
heading=ParagraphStyle('heading',parent=style,fontSize=14,leading=21,spaceAfter=14,textColor=TEAL)
table_style=ParagraphStyle('table',parent=style,fontSize=7.1,leading=10,spaceAfter=0)
table_head=ParagraphStyle('thead',parent=table_style,fontSize=7.1,leading=10,textColor=colors.white)


class ReportDoc(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A4,leftMargin=18*mm,rightMargin=18*mm,
                         topMargin=20*mm,bottomMargin=17*mm,title='PMMAシート下面1次元構造 RCWA全計算結果',
                         author='Codex',subject='保存済みRCWA計算の全結果・全数値・可視化')
        portrait=Frame(18*mm,17*mm,A4[0]-36*mm,A4[1]-37*mm,id='portrait')
        size=landscape(A4)
        wide=Frame(17*mm,17*mm,size[0]-34*mm,size[1]-37*mm,id='wide')
        self.addPageTemplates([PageTemplate(id='normal',frames=[portrait],onPage=self.decorate,pagesize=A4),
                               PageTemplate(id='wide',frames=[wide],onPage=self.decorate,pagesize=size)])
        self.bookmarks=[]

    def decorate(self,canvas,doc):
        w,h=canvas._pagesize
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#b6c9d0'));canvas.setLineWidth(.5)
        canvas.line(18*mm,h-14*mm,w-18*mm,h-14*mm)
        canvas.setFont('JP',8);canvas.setFillColor(TEAL)
        canvas.drawString(18*mm,h-10.5*mm,'PMMAシート下面構造 | 保存済みRCWA結果の全記録')
        canvas.setFillColor(colors.HexColor('#617985'));canvas.setFont('JP',7)
        canvas.drawString(18*mm,10*mm,'2026-11-13 | Auなし全帯域は初期試算 / Auありは550 nmのみ')
        canvas.drawRightString(w-18*mm,10*mm,f'{doc.page}')
        canvas.restoreState()

    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and flowable.style.name=='heading':
            name='b'+str(len(self.bookmarks));text=flowable.getPlainText()
            self.canv.bookmarkPage(name);self.canv.addOutlineEntry(text,name,0,False)
            self.bookmarks.append(dict(page=self.page,title=text))


def para(text,sty=style):
    return Paragraph(escape(str(text)).replace('\n','<br/>'),sty)


def image(path,width=170*mm,max_height=155*mm):
    with PILImage.open(path) as im:w,h=im.size
    scale=min(width/w,max_height/h)
    return Image(str(path),width=w*scale,height=h*scale)


def table(t,width=171*mm,compact=False,colwidths=None):
    n=len(t['headers'])
    if colwidths is None:
        if n==4 and t['headers'][0]=='検証':colwidths=[width*.60,width*.14,width*.14,width*.12]
        elif n==3:colwidths=[width*.32,width*.50,width*.18]
        else:colwidths=[width/n]*n
    st=ParagraphStyle('ct',parent=table_style,fontSize=6.8 if compact else 7.1,
                      leading=8.6 if compact else 10)
    data=[[para(x,table_head) for x in t['headers']]]
    data += [[para(v,st) for v in r] for r in t['rows']]
    tt=Table(data,colWidths=colwidths,repeatRows=1,hAlign='LEFT')
    tt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),TEAL),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f1f6f7')]),
        ('LINEBELOW',(0,0),(-1,0),.6,TEAL),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d5e1e6')),
        ('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),
        ('TOPPADDING',(0,0),(-1,0),5),('BOTTOMPADDING',(0,0),(-1,0),5),
        ('TOPPADDING',(0,1),(-1,-1),2 if compact else 4),('BOTTOMPADDING',(0,1),(-1,-1),2 if compact else 4)]))
    return tt


story=[]
story += [Spacer(1,12*mm),para('PMMAシート下面の1次元構造\nRCWA 全計算結果',title),
          para('Auなし400-700 nm / s・p偏光 / 周期3.72・3.92 µm\n空気溝・水充填 / Au 50 nmの550 nm動作確認',heading),
          para('保存済み結果の再集計・図示 | 2026年11月13日'),Spacer(1,6*mm)]
story += [table(dict(headers=['収録内容','結果'],rows=[['合計値','全712行（計算系列間の同一設定の重複を含む）'],
    ['外部回折次数の結果','39,880行 / 同数の局所次数別結果も収録'],
    ['全帯域Auなし','488条件 / 400-700 nm / 5 nm刻み'],['Auあり','550 nmの8条件のみ'],
    ['新しいRCWA実行','追加していない。既存の数値結果を全て整理した。']]),colwidths=[48*mm,123*mm]),Spacer(1,7*mm),
    para('精度に関する前提',heading),para('全帯域AuなしはM=24、Nz=120の初期試算です。代表3波長の隣接差による収束確認と、全帯域の最終精度を区別して示します。Auありは離散化未収束の動作確認値です。'),
    para('本書の構成',heading),para('構造・材料 → 全R/T/Aスペクトル → 0次と回折成分 → 反射角内外 → 全次数と方向 → Auあり550 nm → 次数・層数・位相の収束 → 物理検証 → 全合計値の付録。'),
    para('全ての次数別数値は、同梱HTMLの切替ビューアとCSV一式で確認できます。報告書の図はPNG/SVGでも収録しています。')]
for s in C['sections']:
    wide=bool(s['figure'])
    story += [NextPageTemplate('wide' if wide else 'normal'),PageBreak()]
    text=[para(s['title'],heading),*[para(p) for p in s['paragraphs']]]
    story += text
    if wide:
        frame_width=landscape(A4)[0]-34*mm-12
        frame_height=landscape(A4)[1]-37*mm-12
        used=sum(p.wrap(frame_width,10000)[1]+p.getSpaceAfter() for p in text)
        max_height=frame_height-used-5*mm
        story += [Spacer(1,3*mm),image(OUT/s['figure'],width=frame_width,max_height=max_height)]
    for t in s['tables']:story += [Spacer(1,3*mm),table(t)]

# Every wavelength's total values. 31 rows/page preserves readable figures.
for item in [t for t in APP if t['run']=='uncoated']:
    for part,start in enumerate(range(0,len(item['rows']),31),1):
        chunk=item['rows'][start:start+31]
        story += [NextPageTemplate('normal'),PageBreak(),para('付録A  Auなし全波長表',heading),para(item['title']),
            para(f'{part}/2 | Rdiff・Tdiffはm≠0の合計。Nφは1 scramble当たり、scrambleは2回。εφは位相平均の変化指標。',small),
            table(dict(headers=item['headers'],rows=chunk),compact=True)]

# Gold and each convergence setting are combined into one table per run.
story += [NextPageTemplate('wide'),PageBreak()]
for i,run in enumerate(['gold','order_16','order_24','order_32','order_40','order_48','slices_60','slices_120','slices_240','slices_480']):
    if i:story.append(PageBreak())
    selected=[t for t in APP if t['run']==run]
    title_text=('付録B  Auあり550 nmの全数値' if run=='gold' else '付録C  収束試験の全数値')
    story += [para(title_text,heading),para(selected[0]['title'].split(' / 周期')[0]),
        para('系列間に同じ設定の行を含みます。数値は全て元の保存結果。Aの微小な負値は丸め誤差。',small)]
    headers=['周期 µm','溝内','偏光',*selected[0]['headers']]
    rows=[]
    for t in selected:
        bits=t['title'].split(' / ')
        per=bits[-3].replace('周期','').replace(' µm','');void=bits[-2];pol=bits[-1]
        rows.extend([[per,void,pol,*r] for r in t['rows']])
    width=landscape(A4)[0]-36*mm
    widths=[34,44,24]+[(width-102)/12]*12
    story.append(table(dict(headers=headers,rows=rows),width=width,compact=True,colwidths=widths))

doc=ReportDoc(PDF);doc.build(story)
(OUT/'pdf_page_index.json').write_text(json.dumps(doc.bookmarks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(pdf=str(PDF),pages=doc.page,bytes=PDF.stat().st_size),ensure_ascii=True))
