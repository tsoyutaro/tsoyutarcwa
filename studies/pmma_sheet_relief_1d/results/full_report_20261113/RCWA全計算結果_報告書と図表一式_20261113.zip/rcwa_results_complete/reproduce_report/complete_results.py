from __future__ import annotations

import base64
import csv
import hashlib
import html
import json
from pathlib import Path
import shutil
import zipfile

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.font_manager import FontProperties

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'source_data'
OUT = ROOT
FIG = OUT/'figures'
DATA = OUT/'tables'
FIG.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)
FONT = FontProperties(fname=r'C:\Windows\Fonts\msgothic.ttc').get_name()
plt.rcParams.update({'font.family':FONT, 'font.size':10, 'axes.titlesize':11,
    'axes.labelsize':10, 'legend.fontsize':8, 'axes.unicode_minus':False,
    'figure.facecolor':'white', 'axes.spines.top':False, 'axes.spines.right':False,
    'savefig.facecolor':'white'})
COLORS = {'s':'#176782', 'p':'#c3633d', 'R':'#176782', 'T':'#168773', 'A':'#b87917'}
RUNS = {}
run_paths = [('uncoated','Auなし 全波長', 'uncoated'), ('gold','Auあり 550 nm', 'gold_smoke_550nm')]
run_paths += [(f'order_{m}', f'次数 M={m}, Nz=120', f'convergence_order/order_{m}') for m in [16,24,32,40,48]]
run_paths += [(f'slices_{n}', f'層数 Nz={n}, M=40', f'convergence_slices/slices_{n}') for n in [60,120,240,480]]
for key, label, relative in run_paths:
    folder = SOURCE/'results'/relative
    s = pd.read_csv(folder/'spectra.csv')
    o = pd.read_csv(folder/'diffraction_orders.csv')
    loc = pd.read_csv(folder/'local_single_pass_orders.csv')
    assert not s.duplicated(['period_nm','void','polarization','wavelength_nm']).any()
    assert np.max(abs(s.R+s['T']+s.A_total-1)) < 1e-10
    agg = o.groupby(['period_nm','void','polarization','wavelength_nm'])[['R_m','T_m']].sum()
    merged = s.set_index(['period_nm','void','polarization','wavelength_nm']).join(agg)
    assert np.max(abs(merged.R-merged.R_m)) < 1e-10
    assert np.max(abs(merged['T']-merged.T_m)) < 1e-10
    zero = o[o.m == 0].set_index(['period_nm','void','polarization','wavelength_nm'])
    s = s.join(zero[['T_m']].rename(columns={'T_m':'T_0'}), on=['period_nm','void','polarization','wavelength_nm'])
    s['T_diffraction'] = s['T']-s.T_0
    local_total = loc.groupby(['period_nm','void','polarization','wavelength_nm'])[['R_PMMA_single_pass','T_water_single_pass']].sum()
    s = s.join(local_total, on=['period_nm','void','polarization','wavelength_nm'])
    RUNS[key] = dict(label=label, path=relative, summary=s, orders=o, local=loc)
S = RUNS['uncoated']['summary']
O = RUNS['uncoated']['orders']
G = RUNS['gold']['summary']
KIN = pd.read_csv(SOURCE/'results/kinematics/order_limits.csv')
CONDITIONS = [(3720.,'air'), (3920.,'air'), (3720.,'water'), (3920.,'water')]


def condname(period, void):
    return f"周期 {period/1000:.2f} µm / {'空気溝' if void=='air' else '水充填'}"


def group(df, period, void, pol=None):
    r = df[(df.period_nm == period)&(df.void == void)]
    if pol:
        r = r[r.polarization == pol]
    return r.sort_values('wavelength_nm')


def savefig(name, fig):
    fig.savefig(FIG/f'{name}.png', dpi=190, bbox_inches='tight')
    fig.savefig(FIG/f'{name}.svg', bbox_inches='tight')
    plt.close(fig)
    return f'figures/{name}.png'


def spectral_grid(name, metric, ylabel, title, styles=None, scale=100):
    fig, axs = plt.subplots(2,2,figsize=(11.7,7.2),sharex=True)
    for ax,(period,void) in zip(axs.flat,CONDITIONS):
        for pol in ['s','p']:
            r = group(S,period,void,pol)
            if styles:
                for key, label, style in styles:
                    ax.plot(r.wavelength_nm, scale*r[key], style, color=COLORS[pol],
                            label=f'{pol}: {label}', lw=1.5)
            else:
                ax.plot(r.wavelength_nm,scale*r[metric],color=COLORS[pol],label=pol,lw=1.7)
        ax.set_title(condname(period,void),loc='left')
        ax.set_ylabel(ylabel)
        ax.grid(alpha=.23)
        ax.legend(ncol=2)
    for ax in axs[-1]: ax.set_xlabel('真空波長 (nm)')
    fig.suptitle(title+'\nAuなし / M=24, Nz=120 / 初期試算',fontsize=14,weight='bold')
    fig.tight_layout()
    return savefig(name,fig)


IMAGES = {}
IMAGES['R'] = spectral_grid('01_reflectance','R','反射率 (%)','全反射スペクトル')
IMAGES['T'] = spectral_grid('02_transmittance','T','透過率 (%)','全透過スペクトル')
IMAGES['Rparts'] = spectral_grid('03_R_specular_diffraction',None,'反射率 (%)','0次反射と回折反射',
                               [('R_0','0次','-'),('R_diffraction','m≠0 合計','--')])
IMAGES['Tparts'] = spectral_grid('04_T_specular_diffraction',None,'透過率 (%)','0次透過と回折透過',
                               [('T_0','0次','-'),('T_diffraction','m≠0 合計','--')])
IMAGES['cone'] = spectral_grid('05_reflection_cone',None,'反射率 (%)','反射角20°以内と20°超',
                             [('R_le_20deg','20°以内','-'),('R_gt_20deg','20°超','--')])
IMAGES['A'] = spectral_grid('06_absorptance_roundoff','A_total','A (×10⁻¹²; パワー比)','Auなしの吸収残差',scale=1e12)

# Numerical summaries: trapezoidal means in wavelength, with no source-spectrum weighting.
metrics = []
for (period,void,pol),r in S.groupby(['period_nm','void','polarization']):
    r=r.sort_values('wavelength_nm')
    item=dict(period_nm=period,void=void,polarization=pol)
    for col in ['R','T','R_0','R_diffraction','T_0','T_diffraction','R_le_20deg','R_gt_20deg']:
        item[col+'_mean_percent']=100*np.trapezoid(r[col],r.wavelength_nm)/300
        imin,imax=r[col].idxmin(),r[col].idxmax()
        item[col+'_min_percent']=100*r.loc[imin,col]
        item[col+'_min_wavelength_nm']=r.loc[imin,'wavelength_nm']
        item[col+'_max_percent']=100*r.loc[imax,col]
        item[col+'_max_wavelength_nm']=r.loc[imax,'wavelength_nm']
    metrics.append(item)
MET=pd.DataFrame(metrics)
MET.to_csv(DATA/'band_statistics_all_metrics.csv',index=False,encoding='utf-8-sig')
S.to_csv(DATA/'uncoated_all_488_results_expanded.csv',index=False,encoding='utf-8-sig')
S[S.wavelength_nm.isin([400,550,700])].to_csv(DATA/'uncoated_400_550_700nm.csv',index=False,encoding='utf-8-sig')
G.to_csv(DATA/'gold_550nm_all_results_expanded.csv',index=False,encoding='utf-8-sig')

# Period, filling-medium and polarization contrasts.
fig,axs=plt.subplots(2,2,figsize=(11.7,7.2),sharex=True)
period_changes=[]
for j,void in enumerate(['air','water']):
    for pol in ['s','p']:
        a=group(S,3720.,void,pol).set_index('wavelength_nm')
        b=group(S,3920.,void,pol).set_index('wavelength_nm')
        for i,key in enumerate(['R','R_le_20deg']):
            delta=100*(b[key]-a[key])
            axs[i,j].plot(delta.index,delta,color=COLORS[pol],label=pol)
        for w in a.index:
            period_changes.append(dict(void=void,polarization=pol,wavelength_nm=w,
                delta_R_pp=100*(b.loc[w,'R']-a.loc[w,'R']),
                delta_T_pp=100*(b.loc[w,'T']-a.loc[w,'T']),
                delta_R_le20_pp=100*(b.loc[w,'R_le_20deg']-a.loc[w,'R_le_20deg'])))
    for i in range(2):
        axs[i,j].axhline(0,color='#66737c',lw=.7)
        axs[i,j].grid(alpha=.23);axs[i,j].legend()
        axs[i,j].set_title(('空気溝' if void=='air' else '水充填')+(' / 全反射' if i==0 else ' / 20°以内'))
        axs[i,j].set_ylabel('3.92 µm - 3.72 µm (pp)')
for ax in axs[-1]:ax.set_xlabel('真空波長 (nm)')
fig.suptitle('隙間0.20 µmを設けたときの変化\n長辺3.72 µm固定 / 負値は反射低下',fontsize=14,weight='bold')
fig.tight_layout();IMAGES['gap']=savefig('07_period_gap_difference',fig)
pd.DataFrame(period_changes).to_csv(DATA/'period_change_all_wavelengths.csv',index=False,encoding='utf-8-sig')

fig,axs=plt.subplots(2,2,figsize=(11.7,7.2),sharex=True)
for j,period in enumerate([3720.,3920.]):
    for pol in ['s','p']:
        a=group(S,period,'air',pol).set_index('wavelength_nm')
        b=group(S,period,'water',pol).set_index('wavelength_nm')
        axs[0,j].plot(a.index,100*(b.R-a.R),color=COLORS[pol],label=pol)
    for void,style in [('air','-'),('water','--')]:
        a=group(S,period,void,'s').set_index('wavelength_nm')
        b=group(S,period,void,'p').set_index('wavelength_nm')
        axs[1,j].plot(a.index,100*(a.R-b.R),style,label='空気溝' if void=='air' else '水充填')
    for i in range(2):
        axs[i,j].set_title(f'周期 {period/1000:.2f} µm')
        axs[i,j].axhline(0,color='#66737c',lw=.7);axs[i,j].grid(alpha=.23);axs[i,j].legend()
    axs[0,j].set_ylabel('水充填R - 空気溝R (pp)')
    axs[1,j].set_ylabel('s偏光R - p偏光R (pp)')
for ax in axs[-1]:ax.set_xlabel('真空波長 (nm)')
fig.suptitle('溝内媒質と偏光による差 / Auなし',fontsize=14,weight='bold')
fig.tight_layout();IMAGES['contrast']=savefig('08_medium_polarization_difference',fig)

# Single-pass local PMMA-side result vs externally observed, phase-averaged result.
IMAGES['local']=spectral_grid('09_local_vs_external',None,'反射率 (%)','局所1回反射とシート全体の外部反射',
    [('R','外部空気側','-'),('R_PMMA_single_pass','PMMA局所1回','--')])

dominant=[]
for period,void in CONDITIONS:
    fig,axs=plt.subplots(2,2,figsize=(11.7,7.2),sharex=True,sharey=True)
    for i,pol in enumerate(['s','p']):
        r=group(O,period,void,pol)
        waves=np.array(sorted(r.wavelength_nm.unique())); ms=np.arange(-14,15)
        for j,(key,label,index) in enumerate([('R_m','空気側 R_m',1.),('T_m','水側 T_m',1.333)]):
            values=r.pivot(index='m',columns='wavelength_nm',values=key).reindex(index=ms,columns=waves).to_numpy()
            ax=axs[i,j]
            image=ax.pcolormesh(waves,ms,np.maximum(values,1e-8),shading='nearest',
                                cmap='viridis',norm=LogNorm(vmin=1e-6,vmax=1))
            limit=index*period/waves
            for sign in [-1,1]:ax.plot(waves,sign*limit,'w--',lw=.9)
            ax.set_title(f'{pol}偏光 / {label}',loc='left');ax.set_ylabel('回折次数 m')
            ax.set_ylim(-14.5,14.5)
    for ax in axs[-1]:ax.set_xlabel('真空波長 (nm)')
    fig.subplots_adjust(right=.86,hspace=.3)
    cax=fig.add_axes([.9,.14,.02,.7]);fig.colorbar(image,cax=cax,label='外部入射パワーに対する比')
    fig.suptitle(f'全次数の反射・透過 / {condname(period,void)}\n白破線：伝搬可能な次数の限界 / Auなし初期試算',fontsize=13,weight='bold')
    IMAGES[f'orders_{int(period)}_{void}']=savefig(f'10_orders_P{int(period)}_{void}',fig)
    for pol in ['s','p']:
        for wave in [400.,550.,700.]:
            rr=group(O,period,void,pol)
            rr=rr[rr.wavelength_nm==wave]
            for col,channel,angle in [('R_m','R','theta_R_air_deg'),('T_m','T','theta_T_output_deg')]:
                top=rr.nlargest(5,col)
                for rank,(_,q) in enumerate(top.iterrows(),1):
                    dominant.append(dict(period_nm=period,void=void,polarization=pol,wavelength_nm=wave,
                        channel=channel,rank=rank,m=int(q.m),efficiency_percent=100*q[col],theta_deg=q[angle]))
pd.DataFrame(dominant).to_csv(DATA/'dominant_orders_400_550_700nm.csv',index=False,encoding='utf-8-sig')

fig,axs=plt.subplots(1,2,figsize=(11.7,4.3),sharey=True)
for ax,period in zip(axs,[3720.,3920.]):
    for channel,label,color in [('R_external_air','外部反射 (空気)','#176782'),
                                 ('T_external_water','外部透過 (水)','#168773'),
                                 ('R_internal_PMMA','局所反射 (PMMA)','#a87829')]:
        r=KIN[(KIN.period_nm==period)&(KIN.channel==channel)]
        ax.step(r.wavelength_nm,r.max_abs_propagating_m,where='mid',label=label,color=color)
    r=KIN[(KIN.period_nm==period)&(KIN.channel=='R_external_air')]
    ax.step(r.wavelength_nm,r.max_abs_m_within_20deg,where='mid',label='外部反射20°以内',color='#8a537c',ls='--')
    ax.set_title(f'周期 {period/1000:.2f} µm');ax.set_xlabel('真空波長 (nm)');ax.grid(alpha=.23);ax.legend()
axs[0].set_ylabel('最大絶対伝搬次数 |m|');fig.suptitle('回折方程式による次数の上限',fontsize=14,weight='bold')
fig.tight_layout();IMAGES['limits']=savefig('11_order_limits',fig)

fig,axs=plt.subplots(1,2,figsize=(11.7,4.6),sharey=True)
for ax,period in zip(axs,[3720.,3920.]):
    for index,label,color in [(1.,'反射：空気','#176782'),(1.333,'透過：水','#168773'),
                               (float(group(S,period,'water','s').query('wavelength_nm==550').n_PMMA.iloc[0]),'PMMA内部','#a87829')]:
        m=np.arange(-int(np.floor(index*period/550)),int(np.floor(index*period/550))+1)
        theta=np.degrees(np.arcsin(m*550/(index*period)))
        ax.plot(m,theta,'o-',ms=3,label=label,color=color)
    ax.axhspan(-20,20,alpha=.09,color='#176782',label='反射の集光半角 ±20°')
    ax.set_title(f'周期 {period/1000:.2f} µm');ax.set_xlabel('回折次数 m');ax.grid(alpha=.23);ax.legend(fontsize=7)
axs[0].set_ylabel('各媒質の法線からの符号付き角度 (°)')
fig.suptitle('550 nmでの全伝搬次数の方向',fontsize=14,weight='bold')
fig.tight_layout();IMAGES['directions']=savefig('12_order_directions_550nm',fig)

# Gold results (only one wavelength was actually calculated).
labels=[]; rvals=[];tvals=[];avals=[]
for period,void in CONDITIONS:
    for pol in ['s','p']:
        rr=group(G,period,void,pol).iloc[0]
        labels.append(f'{period/1000:.2f} µm / {"空気溝" if void=="air" else "水充填"} / {pol}')
        rvals.append(100*rr.R);tvals.append(100*rr['T']);avals.append(100*rr.A_total)
fig,ax=plt.subplots(figsize=(11.7,5.5));y=np.arange(8)
left=np.zeros(8)
for values,key,label in [(rvals,'R','反射 R'),(tvals,'T','透過 T'),(avals,'A','吸収 A')]:
    ax.barh(y,values,left=left,color=COLORS[key],label=label,height=.68)
    for yy,v,l in zip(y,values,left):
        if v>6:ax.text(l+v/2,yy,f'{v:.2f}',ha='center',va='center',color='white',fontsize=9)
    left+=values
ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xlabel('入射パワー (%)');ax.legend(ncol=3,loc='lower center',bbox_to_anchor=(.5,1.01))
fig.suptitle('Auあり 550 nm：全反射・透過・吸収\nM=24, Nz=120（有限層124）/ 動作確認値・離散化未収束',fontsize=13,weight='bold')
fig.tight_layout();IMAGES['goldRTA']=savefig('13_gold_RTA_550nm',fig)

fig,ax=plt.subplots(figsize=(11.7,5.5));y=np.arange(8)
gold_order=[]
for period,void in CONDITIONS:
    for pol in ['s','p']:
        q=group(G,period,void,pol).iloc[0]
        gold_order.append(q)
inside=np.array([100*q.R_le_20deg for q in gold_order]);outside=np.array([100*q.R_gt_20deg for q in gold_order])
ax.barh(y,inside,color='#176782',label='反射20°以内');ax.barh(y,outside,left=inside,color='#a65e7e',label='反射20°超')
ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel('外部入射パワーに対する反射率 (%)');ax.legend()
ax.grid(axis='x',alpha=.23)
fig.suptitle('Auあり 550 nm：集光半角による反射の内訳',fontsize=14,weight='bold')
fig.tight_layout();IMAGES['goldcone']=savefig('14_gold_reflection_cone_550nm',fig)

for key,angle,channel,caption in [('R_m','theta_R_air_deg','R','空気側反射'),('T_m','theta_T_output_deg','T','水側透過')]:
    fig,axs=plt.subplots(2,2,figsize=(11.7,7.2),sharex=True,sharey=True)
    for ax,(period,void) in zip(axs.flat,CONDITIONS):
        for pol in ['s','p']:
            q=group(RUNS['gold']['orders'],period,void,pol).dropna(subset=[angle])
            ax.plot(q[angle],100*q[key],'o-',color=COLORS[pol],ms=4,label=pol,lw=1)
        ax.set_title(condname(period,void),loc='left');ax.grid(alpha=.23);ax.legend();ax.set_yscale('log');ax.set_ylim(1e-5,100)
        ax.set_ylabel(f'{channel}_m (%)')
    for ax in axs[-1]:ax.set_xlabel('法線からの符号付き出射角 (°)')
    fig.suptitle(f'Auあり 550 nm：{caption}の全回折次数\n線は離散回折光を見分ける補助線',fontsize=13,weight='bold')
    fig.tight_layout();IMAGES[f'gold_{channel}']=savefig(f'15_gold_angular_{channel}_550nm',fig)

# Convergence: retain both total metrics and per-order comparisons.
convrows=[]
for axis,values in [('order',[16,24,32,40,48]),('slices',[60,120,240,480])]:
    for before,after in zip(values,values[1:]):
        a=RUNS[f'{axis}_{before}'];b=RUNS[f'{axis}_{after}']
        index=['period_nm','void','polarization','wavelength_nm']
        sa=a['summary'].set_index(index);sb=b['summary'].set_index(index)
        oa=a['orders'].set_index(index+['m']).sort_index();ob=b['orders'].set_index(index+['m']).sort_index()
        for idx in sa.index:
            q=dict(zip(index,idx));q.update(axis=axis,before=before,after=after)
            for field in ['R','T','A_total','R_le_20deg','R_gt_20deg']:
                q['delta_'+field+'_pp']=100*(sb.loc[idx,field]-sa.loc[idx,field])
            orderdiff=oa.loc[idx][['R_m','T_m']].subtract(ob.loc[idx][['R_m','T_m']],fill_value=0).abs()
            q['maximum_order_change_pp']=100*orderdiff.to_numpy().max()
            convrows.append(q)
pd.DataFrame(convrows).to_csv(DATA/'convergence_all_cases_and_steps.csv',index=False,encoding='utf-8-sig')
fig,axs=plt.subplots(1,2,figsize=(11.7,4.3))
for ax,axis,title in zip(axs,['order','slices'],['フーリエ次数収束 (Nz=120固定)','層数収束 (M=40固定)']):
    r=pd.read_csv(SOURCE/f'results/convergence_{axis}/adjacent_changes.csv')
    ax.semilogy(r.resolution,100*r.maximum_change_all_orders_and_totals,'o-',color='#176782',label='全ケース・全次数の最大変化')
    ax.axhline(.1,color='#ac5b39',ls='--',label='許容差 0.1 pp')
    ax.semilogy(r.resolution,100*r.phase_error_bound_observed,':',color='#878785',label='位相平均の変化指標')
    ax.set_xlabel('変更後の M' if axis=='order' else '変更後の Nz');ax.set_ylabel('入射パワー基準の変化 (pp)')
    ax.set_title(title);ax.grid(alpha=.23);ax.legend(fontsize=7)
fig.suptitle('400・550・700 nmでの収束確認 / 全てAuなし',fontsize=14,weight='bold')
fig.tight_layout();IMAGES['conv']=savefig('16_convergence_adjacent_changes',fig)
for axis,values in [('order',[16,24,32,40,48]),('slices',[60,120,240,480])]:
    fig,axs=plt.subplots(2,2,figsize=(11.7,7.2))
    for ax,(period,void) in zip(axs.flat,CONDITIONS):
        for wave,color in [(400.,'#974b37'),(550.,'#27806e'),(700.,'#305a8d')]:
            for pol,style in [('s','-'),('p','--')]:
                yy=[]
                for value in values:
                    rr=group(RUNS[f'{axis}_{value}']['summary'],period,void,pol)
                    yy.append(100*rr[rr.wavelength_nm==wave].R.iloc[0])
                ax.plot(values,yy,style,color=color,marker='o',ms=3,label=f'{wave:g} nm / {pol}')
        ax.set_title(condname(period,void),loc='left');ax.set_ylabel('反射率 R (%)');ax.grid(alpha=.23);ax.legend(ncol=2,fontsize=7)
        ax.set_xlabel('M' if axis=='order' else 'Nz')
    fig.suptitle(('次数' if axis=='order' else '層数')+'変更時の反射率 / 代表3波長・両偏光',fontsize=14,weight='bold')
    fig.tight_layout();IMAGES['conv_'+axis]=savefig('17_convergence_R_'+axis,fig)

comparison=[]
keys=['period_nm','void','polarization','wavelength_nm']
finest=RUNS['order_48']['summary'].set_index(keys)
base=S[S.wavelength_nm.isin([400,550,700])].set_index(keys)
for idx,q in base.iterrows():
    z=dict(zip(keys,idx))
    for col in ['R','T','R_le_20deg','R_gt_20deg']:
        z[col+'_M24_percent']=100*q[col];z[col+'_M48_percent']=100*finest.loc[idx,col]
        z['change_'+col+'_pp']=100*(finest.loc[idx,col]-q[col])
    comparison.append(z)
CMP=pd.DataFrame(comparison);CMP.to_csv(DATA/'initial_M24_vs_M48_anchors.csv',index=False,encoding='utf-8-sig')

fig,axs=plt.subplots(2,2,figsize=(11.7,7.2),sharex=True)
for ax,(period,void) in zip(axs.flat,CONDITIONS):
    for pol in ['s','p']:
        r=group(S,period,void,pol)
        ax.semilogy(r.wavelength_nm,100*r.phase_error,color=COLORS[pol],label=f'{pol}：変化指標')
    ax.axhline(.02,color='#777777',ls='--',lw=.8,label='許容値 0.02 pp')
    ax.set_title(condname(period,void),loc='left');ax.set_ylabel('位相平均の変化指標 (pp)');ax.grid(alpha=.23);ax.legend(fontsize=7)
for ax in axs[-1]:ax.set_xlabel('真空波長 (nm)')
fig.suptitle('位相平均の収束指標 / 全488条件',fontsize=14,weight='bold');fig.tight_layout();IMAGES['phase']=savefig('18_phase_average_error',fig)
fig,axs=plt.subplots(1,2,figsize=(11.7,4.5))
for period,void in CONDITIONS:
    for pol,style in [('s','-'),('p','--')]:
        rr=group(S,period,void,pol)
        axs[0].plot(rr.wavelength_nm,rr.phase_points_per_scramble,style,label=condname(period,void)+' / '+pol,lw=.8)
    rr=group(S,period,void,'p')
    axs[1].plot(rr.wavelength_nm,rr.runtime_seconds,label=condname(period,void),lw=1)
axs[0].set_yscale('log',base=2);axs[0].set_ylabel('1 scramble当たりの位相点数');axs[0].set_title('scramble数は2')
axs[1].set_ylabel('計測された局所計算＋s/p平均処理 (秒)');axs[1].set_title('244件の波長・形状・媒質計算')
for ax in axs:ax.set_xlabel('真空波長 (nm)');ax.grid(alpha=.23);ax.legend(fontsize=6,ncol=2)
fig.suptitle('位相点数と計測実行時間 / 計測条件に依存する参考値',fontsize=13,weight='bold')
fig.tight_layout();IMAGES['cost']=savefig('19_phase_samples_runtime',fig)

pmma=pd.read_csv(SOURCE/'data/Szczurowski.csv');au=pd.read_csv(SOURCE/'data/Au_Johnson_1972.csv')
fig,axs=plt.subplots(1,3,figsize=(11.7,3.5))
q=S.drop_duplicates('wavelength_nm').sort_values('wavelength_nm')
axs[0].plot(q.wavelength_nm,q.n_PMMA,color='#176782');axs[0].axhline(1.333,ls='--',color='#168773',label='水 1.333')
axs[0].set_ylabel('屈折率 n');axs[0].set_title('PMMAと水');axs[0].legend()
wl=np.arange(400.,701.);an=np.interp(wl,au.wavelength_nm,au.n);ak=np.interp(wl,au.wavelength_nm,au.k)
axs[1].plot(wl,an,label='n');axs[1].plot(wl,ak,label='k');axs[1].set_title('Au Johnson-Christy');axs[1].legend()
eps=(an+1j*ak)**2;axs[2].plot(wl,eps.real,label='Re ε');axs[2].plot(wl,eps.imag,label='Im ε');axs[2].set_title('Auの複素誘電率');axs[2].legend()
for ax in axs:ax.set_xlabel('真空波長 (nm)');ax.grid(alpha=.23)
fig.suptitle('計算に使用した材料定数',fontsize=14,weight='bold');fig.tight_layout();IMAGES['materials']=savefig('20_optical_constants',fig)

for key,angle,channel,caption in [('R_m','theta_R_air_deg','R','空気側反射'),('T_m','theta_T_output_deg','T','水側透過')]:
    fig,axs=plt.subplots(2,2,figsize=(11.7,7.2),sharex=True,sharey=True)
    for ax,(period,void) in zip(axs.flat,CONDITIONS):
        for pol in ['s','p']:
            q=group(O,period,void,pol);q=q[q.wavelength_nm==550].dropna(subset=[angle])
            ax.plot(q[angle],100*q[key],'o-',color=COLORS[pol],ms=4,label=pol,lw=1)
        ax.set_title(condname(period,void),loc='left');ax.grid(alpha=.23);ax.legend();ax.set_yscale('log');ax.set_ylim(1e-5,100)
        ax.set_ylabel(f'{channel}_m (%)')
    for ax in axs[-1]:ax.set_xlabel('法線からの符号付き出射角 (°)')
    fig.suptitle(f'Auなし 550 nm：{caption}の全回折次数\n線は離散回折光を見分ける補助線',fontsize=13,weight='bold')
    fig.tight_layout();IMAGES[f'bare_{channel}']=savefig(f'21_uncoated_angular_{channel}_550nm',fig)

for period in [3720,3920]:
    shutil.copy2(SOURCE/f'results/geometry/conditions_P{period}.png',FIG/f'geometry_P{period}.png')
    IMAGES[f'geometry_{period}']=f'figures/geometry_P{period}.png'


def records(df):
    return json.loads(df.to_json(orient='records',double_precision=14,force_ascii=False))


def table_from(df, cols, headers, percent_cols=(), digits=3):
    rows=[]
    for _,q in df.iterrows():
        row=[]
        for col in cols:
            value=q[col]
            if pd.isna(value): row.append('-')
            elif col=='void':row.append('空気溝' if value=='air' else '水充填')
            elif col=='period_nm':row.append(f'{value/1000:.2f}')
            elif col=='wavelength_nm':row.append(f'{value:g}')
            elif col in percent_cols:row.append(f'{100*value:.{digits}f}')
            elif isinstance(value,(float,np.floating)):row.append(f'{value:.{digits}f}')
            else:row.append(str(value))
        rows.append(row)
    return dict(headers=headers,rows=rows)


stats=MET.copy()
summary_table=table_from(stats,['period_nm','void','polarization','R_mean_percent','R_min_percent','R_min_wavelength_nm','R_max_percent','R_max_wavelength_nm','T_mean_percent'],
    ['周期 µm','溝内','偏光','平均R %','最小R %','λ nm','最大R %','λ nm','平均T %'])
anchor_cols=['period_nm','void','polarization','wavelength_nm','R','T','R_le_20deg','R_gt_20deg']
anchor_headers=['周期 µm','溝内','偏光','λ nm','R %','T %','R≤20° %','R>20° %']
gold_table=table_from(G,['period_nm','void','polarization','R','T','A_total','R_le_20deg','R_gt_20deg'],
    ['周期 µm','溝内','偏光','R %','T %','A %','R≤20° %','R>20° %'],
    ['R','T','A_total','R_le_20deg','R_gt_20deg'])

SECTIONS=[]
def section(title,paragraphs,figure=None,tables=None):
    SECTIONS.append(dict(title=title,paragraphs=paragraphs,figure=figure,tables=tables or []))

section('01  計算済み範囲と結果の読み方',[
    'Auなしは400-700 nmを5 nm刻み、61波長×2周期×2媒質×2偏光の488条件。Auありは550 nmの8条件のみです。次数収束120条件、層数収束96条件も保存されています。新しいRCWA計算は追加せず、これまで得られた結果を全て再集計しました。',
    '全帯域のAuなしデータはM=24（x方向49調和成分）、Nz=120の初期試算です。位相平均は全488条件で所定の変化指標を満たしました。一方、全帯域の離散化誤差が確定したわけではありません。',
    '反射・透過・吸収は上側空気からの最初の入射パワーを100%とします。Rは外部空気への全反射、Tは半無限水への全透過です。反射の20°以内には0次も含み、角度は上向き法線から測ります。ppはパーセントポイントです。',
    '図中の線は5 nm間隔の計算点を結んだものです。極値とその波長は、この計算格子上の値であり、連続波長での真の極値を探索した結果ではありません。',
    '712行は保存した計算系列の全行数で、同じ物理条件・同じ数値設定が別系列に含まれる重複を含みます。各系列を統合して平均した数ではありません。'],tables=[dict(headers=['データ区分','波長・解像度','偏光別結果数'],rows=[
        ['Auなし全帯域','400-700 nm / M24 / Nz120','488'],['Auあり動作確認','550 nm / M24 / Nz120 (124層)','8'],
        ['次数収束','400, 550, 700 nm / M16,24,32,40,48','120'],['層数収束','400, 550, 700 nm / Nz60,120,240,480','96']])])
for period in [3720,3920]:
    section(f'02  構造モデル / 周期{period/1000:.2f} µm',[
        '上から空気、十分厚いPMMAシート、下向きに突出する逆台形PMMA構造、半無限水です。長辺3.72 µm、短辺1.50 µm、高さ1.50 µmを固定し、周期だけを変更しました。x方向に周期的、y方向は一様です。',
        f'根元の隙間は{(period-3720)/1000:.2f} µm。図の上段はAuなし、下段はAuあり、左列は空気溝、右列は水充填です。空気溝の場合も、突出端またはAu表面に接する平坦な水面より下は水です。シート厚さの描画のみ模式的です。'],IMAGES[f'geometry_{period}'])
section('03  材料定数・Au膜厚・シートの扱い',[
    'PMMAは既存Szczurowski CSVのnを線形補間し、k=0としました。400-404.7 nmだけ、添付式の400 nm値とCSV最初の点を直線接続しています。水はn=1.333、k=0。AuはJohnson-Christy CSVのnとkを個別に補間しました。',
    'Auは下側からの垂直蒸着を仮定します。斜面角は水平から53.4986°。公称50 nmは水平面の厚さで、斜面の法線方向は50 cos(53.4986°)=29.7422 nm、同じ高さで測るx方向の幅は37.0000 nmです。',
    '厚いシートの往復位相だけを平均し、格子・空気溝・Au薄膜内の干渉はRCWAに保持します。PMMA上面のフレネル反射、戻った各回折次数の再反射、PMMA内部での全反射も含めました。'],IMAGES['materials'])
section('04  Auなし / 全反射スペクトル',[
    '水充填では反射率が4%付近、空気溝ではそれより高く、波長に対する変動も大きくなりました。これは今回のモデル・寸法・材料に対する結果です。',
    '上側の空気/PMMA界面も含む計算です。550 nmでこの平坦な上面だけのフレネル反射率は約3.90%なので、水充填時の約4%の結果を下面構造だけの反射率として読まないでください。'],IMAGES['R'])
section('05  Auなし / 全透過スペクトル',[
    'PMMA・空気・水を無損失としているため、各計算点でT=1-Rです。水充填では大半の入射パワーが水へ透過し、空気溝では反射増加に応じて全透過が低下しました。',
    'ここでのTは0次透過だけではなく、伝搬可能な全回折次数の合計です。透過パワーが高いことと、透過光が正面の0次に集中することは同じ意味ではありません。'],IMAGES['T'])
section('06  Auなし / 帯域統計と極値',[
    '平均値は400-700 nmで台形積分し、帯域幅300 nmで割った波長平均です。光源スペクトル、視感度、検出器感度による重みは付けていません。',
    '下表には全反射の平均・格子上の最小/最大とその波長、全透過の平均を記載します。0次・回折成分・集光角内外を含む全統計は付属CSVに収録しました。'],tables=[summary_table])
for wave in [400,550,700]:
    section(f'07  Auなし / {wave} nmの全8条件',[
        '同じ波長で、周期・溝内媒質・偏光の組合せを直接比較した表です。全て全帯域試算と同じM=24、Nz=120の値で、後述の高次数計算と置き換えていません。'],
        tables=[table_from(S[S.wavelength_nm==wave],anchor_cols,anchor_headers,['R','T','R_le_20deg','R_gt_20deg'])])
section('08  0次反射と回折反射の内訳',[
    '実線がR0、破線がm≠0の反射を全て足したRdiffです。R0+Rdiff=R。空気溝では回折反射の寄与が大きくなる波長があり、鏡面反射率だけでは全反射を表せません。',
    '左右対称な構造へ垂直入射しているため、正負の同じ絶対次数は同じパワーになります。図の回折合計には+mと-mの両方を含みます。'],IMAGES['Rparts'])
section('09  0次透過と回折透過の内訳',[
    '実線がT0、破線がm≠0の全透過です。T0は保存済み次数別CSVから抽出し、Tdiff=T-T0として再集計しました。',
    '波長と偏光によって0次と回折次数への配分が変わります。全透過が約96%であっても、残りの回折透過を除いて0次透過だけを見る場合には別の数値になります。'],IMAGES['Tparts'])
section('10  反射角20°以内・外の全スペクトル',[
    '実線は上側空気中で法線から20°以内へ出る全反射、破線は20°を超える全反射です。両者の和はRです。これは入射角を20°まで走査した結果ではなく、垂直入射に対する集光範囲の区分です。',
    'どの次数が20°以内に入るかは波長と周期で変わるため、集光角内のスペクトルには次数境界で配分の変化が現れます。'],IMAGES['cone'])
section('11  周期変更 / 隙間0.20 µmの効果',[
    '図は周期3.92 µmの値から3.72 µmの値を引いたものです。長辺を変えずに周期だけを変えています。負値は隙間を設けた方が反射が小さいことを表します。',
    '空気溝の波長平均Rは、周期3.72 µmでs=16.683%、p=12.262%、周期3.92 µmでs=18.169%、p=13.515%でした。この平均では隙間ありの方が反射が増えています。水充填での平均差はsで約0.015 pp、pで約0.002 ppと小さく、現状の離散化・位相精度で有意な優劣を断定しません。',
    '差の符号は波長で反転し、隙間0.20 µmが全帯域で反射を下げるという結果ではありません。550 nmの空気溝s偏光では、全反射が約4.684 pp減る一方、20°超の反射は約1.767 pp増えています。',
    '従って、全反射の大小と、ある集光半角で検出される反射の大小を分けて評価する必要があります。0.20 µmは比較設計の初期案であり、製造・光学双方の最適値を確定したものではありません。'],IMAGES['gap'])
section('12  媒質と偏光による差',[
    '上段は水充填Rから空気溝Rを引いた差、下段はs偏光Rからp偏光Rを引いた差です。今回の全帯域試算では、水充填の方が全反射が小さくなっています。',
    '図は数値差を示したもので、特定の波長のピークを表面プラズモン等の単一機構に同定する解析は行っていません。AuなしのピークをAuに由来する現象として解釈することもできません。'],IMAGES['contrast'])
section('13  局所1回反射とシート全体の外部反射',[
    '破線はPMMAから下面構造へ1回だけ入射した局所反射率、実線は上面を含むシート全体の外部反射率です。局所値はPMMA側への入射パワーを基準、外部値は最初の空気側入射パワーを基準とします。',
    '基準面と多重反射の扱いが違うため、両者を単純に足し引きして吸収などの成分に解釈してはいけません。局所計算の全次数も付属CSVとHTMLで確認できます。'],IMAGES['local'])
section('14  Auなしの吸収・エネルギー保存',[
    f"Auなしの全488条件で、|A|=|1-R-T|の最大値は{S.A_total.abs().max():.6g}です。図はこの丸め誤差を10の-12乗単位で拡大しています。物理的な吸収ピークや利得ではありません。",
    '全体のエネルギー保存は確認できますが、エネルギー保存だけで回折効率の離散化収束が証明されるわけではありません。特にp偏光の短波長側では、次数を増やすと保存則を保ったまま配分が変わります。'],IMAGES['A'])
section('15  伝搬可能次数の波長依存',[
    '垂直入射ではsinθm=mλ/(nΛ)。伝搬条件は|m|λ<nΛ、等号は90°のカットオフで法線方向のパワーは0です。最大絶対次数Mは、nΛ/λが整数でなければその床関数です。',
    '400 nmでは、周期3.72 µmの外部反射が±9次、水透過が±12次、PMMA内部が±14次までです。周期3.92 µmでは水透過が±13次まで増えます。700 nmでは両周期とも外部反射±5次・水透過±7次です。',
    'これは運動学的に許される上限であり、各次数が強く励起されるという意味ではありません。数値打ち切り次数M=24や48とも区別してください。'],IMAGES['limits'])
section('16  550 nmでの次数と出射方向',[
    '符号はx方向、角度の絶対値は各媒質の法線からの傾きです。外部反射は上向き法線、透過は下向き法線を基準とします。PMMA内では許されても空気側へ出られない次数は上面で全反射します。',
    '550 nmの外部反射は周期3.72 µmで±6次、3.92 µmで±7次までです。両周期とも外部反射20°以内に入るのはm=0,±1,±2で、水透過は±9次までです。'],IMAGES['directions'])
for period,void in CONDITIONS:
    section('17  全次数スペクトル / '+condname(period,void),[
        '左列は外部空気側反射、右列は水側透過、上段はs偏光、下段はp偏光です。色は外部入射パワー比の対数で、m=0と全ての非零次数を同時に表示しています。',
        '白い破線は伝搬可能領域の限界です。m=±14までの表示が、この帯域での全ての外部伝搬次数を含みます。保持した調和成分は±24ですが、それより外側の遠方伝搬パワーは0です。正負次数の対称性も確認できます。'],IMAGES[f'orders_{int(period)}_{void}'])
for key,label in [('bare_R','反射'),('bare_T','透過')]:
    section('18  Auなし550 nm / 各次数の'+label+'と方向',[
        '保存された全回折光を、それぞれの出射角に対して表示しました。各点が1本の回折光です。縦軸は対数で、線は点同士を見分けるための補助です。',
        '0次は0°に対応します。カットオフやエバネッセント次数は通常の遠方伝搬光として描きません。任意の計算波長について同じ数値をHTMLの結果ビューアで確認できます。'],IMAGES[key])
section('19  Auあり550 nm / 全反射・透過・吸収',[
    'Auありの計算済み結果は以下の8条件のみです。全てM=24、Nz=120（実際の有限層数124）の動作確認値であり、Auモデルの次数・層数収束は行っていません。',
    f"全8条件でR、T、Aは非負で、合計は100%です。Aの範囲は{100*G.A_total.min():.3f}-{100*G.A_total.max():.3f}%でした。空気溝p偏光ではAが約57-59%になります。", 
    '同じ550 nmのAuなしと比べると、全8条件で全反射が増え、全透過が減り、Auでの吸収が生じました。Au膜の全帯域スペクトルや共鳴波長を、この1波長の結果から推定しません。'],IMAGES['goldRTA'])
section('20  Auあり550 nm / 全数値表',[
    '吸収は構造全体のA_total=1-ΣRm-ΣTmです。出射回折次数mに対して1-Rm-Tmを吸収と定義することはできません。Auを含む本モデルでは、体積損失はAuにのみ与えています。'],tables=[gold_table])
section('21  Auあり550 nm / 反射の集光角内外',[
    '20°以内と20°超の反射を分けて示します。0次は20°以内に含まれます。Auありでも、外部媒質が同じなので、各次数の角度と伝搬可否はAuなしと同じです。変わるのは各次数へのパワー配分です。'],IMAGES['goldcone'])
for key,label in [('gold_R','反射'),('gold_T','透過')]:
    section('22  Auあり550 nm / 全次数の'+label+'と方向',[
        '各点は保存した回折効率で、縦軸は対数です。s/pと溝内媒質により各次数の強度は異なります。全ての数値を表として確認する場合は、HTMLまたはsource_data内の次数別CSVを使用してください。'],IMAGES[key])
section('23  次数・層数の隣接差による判定',[
    '400/550/700 nm、両周期、両媒質、s/pを比較しました。R/T/A、20°内外、全てのRm/Tmのうち最大の隣接変化を図示します。許容差は1e-3、すなわち0.1 ppです。',
    '次数はM=32→40で0.0744201 pp、40→48で0.0510586 pp。層数はNz=120→240で0.0164103 pp、240→480で0.00409569 pp。各系列の最後の2段階は既定の隣接差判定に合格しています。',
    'この判定は真値への厳密な誤差上界ではありません。また次数試験はNz=120固定、層数試験はM=40固定で、M=48かつNz=480を全帯域で確認した結果ではありません。'],IMAGES['conv'])
for key,label in [('conv_order','次数'),('conv_slices','層数')]:
    section('24  各条件の反射率と'+label+'の関係',[
        '赤系は400 nm、緑系は550 nm、青系は700 nm。実線はs、破線はpです。特に400 nmの空気溝p偏光には次数依存が残り、M=24の全帯域データを最終収束値として扱えないことが分かります。',
        'Tは無損失条件で1-Rとなるため同じ情報を反転した値です。各次数の変化と全R/T/Aの数値は、全ケース・全ステップのCSVにも収録しています。'],IMAGES[key])
max_cmp=CMP.loc[CMP.change_R_pp.abs().idxmax()]
section('25  初期M24データとM48の差',[
    f"代表3波長に限り、Nz=120を固定して初期M24とM48を直接比較しました。最大の全反射差は{abs(max_cmp.change_R_pp):.6f} pp（{max_cmp.period_nm/1000:.2f} µm、{'空気溝' if max_cmp.void=='air' else '水充填'}、{max_cmp.polarization}偏光、{max_cmp.wavelength_nm:g} nm）です。",
    '下表の符号付き差はM48-M24です。M24の全帯域初期結果はそのまま保存し、限られた波長の高次数結果で補間や置き換えをしていません。'],
    tables=[table_from(CMP,['period_nm','void','polarization','wavelength_nm','R_M24_percent','R_M48_percent','change_R_pp'],
        ['周期 µm','溝内','偏光','λ nm','M24 R %','M48 R %','差 pp'],digits=5)])
section('26  位相平均の変化指標',[
    f"全488条件で変化指標は2e-4以下、最大値は{S.phase_error.max():.9g}（パワー比）、約{100*S.phase_error.max():.6f} ppです。", 
    '2つのSobol scramble間の差、および点数倍増前後の差を用いた数値指標です。厳密な誤差上界ではありません。±mの縮退は同じ位相として保持しています。',
    '位相平均の収束と、フーリエ次数・層数・波長刻みの収束はそれぞれ別です。全488条件の位相平均合格を、全ての離散化の収束と読み替えないでください。'],IMAGES['phase'])
section('27  位相点数と実行時間',[
    f"全帯域初期試算の1 scramble当たりの位相点数は{int(S.phase_points_per_scramble.min())}-{int(S.phase_points_per_scramble.max())}点で、scrambleは2つです。", 
    '実行時間は保存されたruntime_secondsを表示します。pの行は同一波長・同一構造についてs/p両方の処理が終わった時点の累積値なので、sとpの行を合算して総時間とはしません。',
    f"244件のp行の計測時間の合計は{group(S,3720.,'air','p').runtime_seconds.sum()+group(S,3920.,'air','p').runtime_seconds.sum()+group(S,3720.,'water','p').runtime_seconds.sum()+group(S,3920.,'water','p').runtime_seconds.sum():.1f}秒です。並列実行やI/Oを含むチャット全体の経過時間、あるいは統一したベンチマーク値ではありません。"],IMAGES['cost'])

checks=json.loads((SOURCE/'results/validation/checks.json').read_text(encoding='utf-8'))['checks']
section('28  独立した物理式・対称性による検証',[
    '平坦界面のフレネル式、平坦50 nm Au膜の独立したAiry式、無損失格子の全入射チャネルでの保存則、±mの対称性、620 nmの空気側カットオフ等を検証し、保存されている12項目は全て合格しています。',
    'これらは実装・規格化・基本物理の検査です。対象のAu格子についての離散化収束、実試料の膜質・濡れ状態との一致を代替する検査ではありません。'],
    tables=[dict(headers=['検証','最大誤差','許容値','判定'],rows=[[q['name'],f"{q['error']:.3g}",f"{q['tolerance']:.3g}",'合格' if q['passed'] else '不合格'] for q in checks])])
section('29  全数値と、今回まだ得られていない結果',[
    '付録にはAuなし488条件の全波長表、Auあり8条件の全表、次数収束120条件、層数収束96条件を掲載します。各回折次数の全数値はHTMLの切替ビューアおよびsource_data内のCSVに収録します。',
    '未計算・未確認：Auあり400-700 nmスペクトル、Au格子の次数・層数収束、全帯域の高M・高Nz同時確認、5 nmより細かい波長刻みの収束、入射角走査、濡れ・メニスカス・粗さ・密着層の影響です。',
    '結論として、水充填と空気溝では反射・回折の配分が大きく異なります。隙間の有無の効果は波長・偏光・集光角によって変わります。Auあり550 nmでは吸収が大きくなりますが、その定量値は離散化未収束の試算として扱ってください。'])

payload=dict(sections=SECTIONS,images=IMAGES,metrics=records(MET),comparison=records(CMP),
    counts={k:dict(label=v['label'],summary=len(v['summary']),orders=len(v['orders']),local=len(v['local'])) for k,v in RUNS.items()},
    max_absorption_residual=float(S.A_total.abs().max()),max_phase_error=float(S.phase_error.max()))
(OUT/'report_content.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
